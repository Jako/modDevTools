# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.4.0] - 2026-11-25

### Added

- Wildcard and regular expression modes in the search and replace
- Options to ignore case and find whole words in the plain text search
- Preview to select the matches to replace

### Changed

- Don't expose server paths in the manager page options
- Don't save an element when skipping a match

### Fixed

- Check the view permissions in the content search
- Restrict the change template processor to the template and clear the resource cache
- Fix replacing in templates in MODX 3
- Search the current file content of static elements
- Fix search and replace issues with multibyte and HTML characters, `%` and `_`
- Fix PHP errors without an initialized user or a further occurrence
- Fix JavaScript errors in the resources grid, element panels and resource form
- Fix the change template window showing the template ID

## [1.3.9] - 2026-03-18

### Fixed

- Fix wrong class alias in MODX 3 for modElementGetInsertProperties [#7]

## [1.3.8] - 2023-11-10

### Added

- System settings tab in custom manager page

## [1.3.7] - 2023-11-05

### Changed

- Display the template edit link as icon
- Display the template edit link in MODX 3.x too

### Fixed

- Don't list all Resources as unpublished in MODX 3.x [#5]

## [1.3.6] - 2023-03-10

### Added

- Disable regenerate element links in setup by option [#4]
- Add edit template link [#3]

## [1.3.5] - 2022-08-18

### Fixed

- Fix regenerate usage link database in the CMP
- Fix empty resources tab in MODX 3

## [1.3.4] - 2022-08-16

### Fixed

- Fix showing NaN dates in Safari

## [1.3.3] - 2022-04-06

### Fixed

- Fix save button disabled on every tab change [#1]

## [1.3.2] - 2022-04-06

### Fixed

- Fix an error when performing replace and skip on the search page

### Changed

- Update Russian language (thanks to Ibochkarev)

## [1.3.1] - 2022-03-24

### Added

- Duplicate and Quick Duplicate (split-)buttons for templates and chunks

### Fixed

- Fix for not found templates in chunks

## [1.3.0] - 2022-03-16

### Changed

- Code refactoring
- Full MODX 3 compatibility

## [1.1.4] - 2021-08-16

### Fixed

- Fix for not found resources in templates
- Fix missing tabs in chunks

## [1.1.3] - 2020-11-10

### Added

- Compress assets

### Fixed

- Style fix for disabled context key in breadcrumb home

## [1.1.2] - 2020-11-05

### Added

- Option for enabling the context key in breadcrumb home

## [1.1.1] - 2019-10-31

### Added

- Show context key in breadcrumb home

## [1.1.0] - 2019-06-24

### Added

- Edit and Quick Edit chunks/templates from modDevTools CMP directly
- Regenerate the chunks, templates and snippets usage link database in the CMP
- Improved Ext JS display
- Updated manager style
- Search in CMP is case sensitive

### Removed

- Dropped Revo 2.2 compatibility

## [1.0.0] - 2014-10-23

### Added

- Resource list on Snippet update page
- Resource list on Chunk update page
- Elements tabs and action buttons in resource grids are displayed depending on user access permissions
- Breadcrumbs are displayed in Resource Overview

### Fixed

- Fix Ctrl-Z

## [0.9.8] - 2014-10-21

### Added

- Search and Replace panel for elements
- BreadCrumbs panel for resource edit page

### Fixed

- Fix log messages while install

## [0.9.5] - 2014-10-09

### Added

- Template list on chunk page
- Name of the chunk is highlighted in template code for Ace
- Save child element in focus instead of parent

## [0.9.0] - 2014-09-30

### Added

- Initial release
