<?php
/**
 * modDevTools
 *
 * Copyright 2014-2019 by Vitaly Kireev <kireevvit@gmail.com>
 * Copyright 2019-2022 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package moddevtools
 * @subpackage classfile
 */

require_once dirname(dirname(__DIR__)) . '/vendor/autoload.php';

/**
 * Class Agenda
 */
class modDevTools extends \TreehillStudio\ModDevTools\ModDevTools
{
}
