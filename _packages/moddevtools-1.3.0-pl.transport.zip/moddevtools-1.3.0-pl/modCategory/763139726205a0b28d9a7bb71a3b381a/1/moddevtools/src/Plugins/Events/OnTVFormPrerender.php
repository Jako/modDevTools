<?php
/**
 * @package moddevtools
 * @subpackage plugin
 */

namespace TreehillStudio\ModDevTools\Plugins\Events;

use TreehillStudio\ModDevTools\Plugins\Plugin;

class OnTVFormPrerender extends Plugin
{
    public function process()
    {
    }
}
