<?php
/**
 * @package moddevtools
 * @subpackage plugin
 */

namespace TreehillStudio\ModDevTools\Plugins\Events;

use TreehillStudio\ModDevTools\Plugins\Plugin;

class OnTVFormSave extends Plugin
{
    public function process()
    {
    }
}
