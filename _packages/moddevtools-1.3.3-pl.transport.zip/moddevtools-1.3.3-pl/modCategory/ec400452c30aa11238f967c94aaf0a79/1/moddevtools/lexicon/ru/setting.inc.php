<?php
/**
 * Setting Lexicon Entries for modDevTools
 *
 * @package moddevtools
 * @subpackage lexicon
 */
$_lang['setting_moddevtools.breadcrumb_limit'] = 'Лимит хлебных крошек';
$_lang['setting_moddevtools.breadcrumb_limit_desc'] = 'Лимит отображаемых записей хлебных крошек.';
$_lang['setting_moddevtools.debug'] = 'Отладка';
$_lang['setting_moddevtools.debug_desc'] = 'Записывать отладочную информацию в журнал ошибок MODX.';
$_lang['setting_moddevtools.show_breadcrumb_context'] = 'Показать контекст навигационной цепочки';
$_lang['setting_moddevtools.show_breadcrumb_context_desc'] = 'Показать ключ контекста в пути хлебных крошек.';
