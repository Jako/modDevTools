<?php
/**
 * @package moddevtools
 * @subpackage plugin
 */

namespace TreehillStudio\ModDevTools\Plugins\Events;

use TreehillStudio\ModDevTools\Plugins\Plugin;

class OnSnipFormSave extends Plugin
{
    public function process()
    {
    }
}
